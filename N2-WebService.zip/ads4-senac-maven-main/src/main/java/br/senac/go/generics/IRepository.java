package br.senac.go.generics;

public interface IRepository {
}
