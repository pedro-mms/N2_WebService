# Projeto E-commerce

## Banco de dados

![Modelo de banco de dados](./assets/image/banco.png "Modelo de banco de dados escrito na 3ª Forma Normal - 3FN")

## UML

![Uml do pojeto](./assets/image/uml.png "Modelo UML")

## Tecnologias utilizadas
